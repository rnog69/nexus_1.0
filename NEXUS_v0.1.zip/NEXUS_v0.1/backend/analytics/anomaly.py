import numpy as np

def zscore_anomaly(values):
    x = np.asarray(values, dtype=float)
    if len(x) < 2:
        return np.zeros_like(x)
    std = x.std()
    if std == 0:
        return np.zeros_like(x)
    return (x - x.mean()) / std
