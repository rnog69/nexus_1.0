def decline_rate(q_initial: float, q_current: float, years: float) -> float:
    if years <= 0 or q_initial <= 0 or q_current <= 0:
        return 0.0
    return 1 - (q_current / q_initial) ** (1 / years)

def material_balance_index(p_initial: float, p_current: float) -> float:
    if p_initial == 0:
        return 0.0
    return (p_initial - p_current) / p_initial
