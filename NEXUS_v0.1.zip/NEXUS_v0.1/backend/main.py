from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="NEXUS API", version="0.1.0")

class Scenario(BaseModel):
    production_change_pct: float = 0
    oil_price: float = 75
    duration_days: int = 30

@app.get("/health")
def health():
    return {"status": "online", "system": "NEXUS"}

@app.get("/api/field")
def field():
    return {
        "field_health": 91,
        "production_bopd": 12480,
        "forecast_bopd": 11860,
        "risk_exposure_usd": 1240000,
        "active_alerts": 4
    }

@app.get("/api/wells")
def wells():
    return [
        {"name":"NEXUS-01","status":"Watch","oil_bopd":1840,"risk":"Medium"},
        {"name":"NEXUS-02","status":"Healthy","oil_bopd":2210,"risk":"Low"},
        {"name":"NEXUS-03","status":"Investigate","oil_bopd":1320,"risk":"High"},
        {"name":"NEXUS-04","status":"Healthy","oil_bopd":1980,"risk":"Low"},
    ]

@app.post("/api/scenario")
def scenario(s: Scenario):
    baseline = 12480
    projected = baseline * (1 + s.production_change_pct / 100)
    revenue = projected * s.oil_price * s.duration_days
    return {
        "projected_production_bopd": round(projected, 2),
        "gross_revenue_usd": round(revenue, 2)
    }
