# NEXUS v0.1
Autonomous Energy Engineering Command Center.

## Stack
- Next.js / React frontend
- FastAPI backend
- Python engineering/analytics layer
- Docker-ready structure

## Run backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

## Run frontend
```bash
cd frontend
npm install
npm run dev
```

This is a starter vertical slice for the NEXUS architecture.
