'use client';
import { useEffect, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export default function Home() {
  const [field,setField] = useState(null);
  const [wells,setWells] = useState([]);

  useEffect(() => {
    fetch(`${API}/api/field`).then(r=>r.json()).then(setField).catch(()=>{});
    fetch(`${API}/api/wells`).then(r=>r.json()).then(setWells).catch(()=>{});
  },[]);

  return (
    <main>
      <header>
        <div>
          <div className="eyebrow">AUTONOMOUS ENERGY ENGINEERING</div>
          <h1>NEXUS</h1>
          <p>Field Command Center</p>
        </div>
        <span className="online">● SYSTEM ONLINE</span>
      </header>

      <section className="hero">
        <div><small>FIELD HEALTH</small><strong>{field?.field_health ?? "--"}</strong><em>/100</em></div>
        <div><small>PRODUCTION</small><strong>{field?.production_bopd?.toLocaleString() ?? "--"}</strong><em>BOPD</em></div>
        <div><small>30D FORECAST</small><strong>{field?.forecast_bopd?.toLocaleString() ?? "--"}</strong><em>BOPD</em></div>
        <div><small>RISK EXPOSURE</small><strong>${field ? (field.risk_exposure_usd/1e6).toFixed(2) : "--"}M</strong></div>
      </section>

      <section className="panel">
        <div className="panelTitle">WELL WATCHLIST <span>{wells.length} WELLS</span></div>
        {wells.map(w => (
          <div className="well" key={w.name}>
            <b>{w.name}</b><span>{w.status}</span><span>{w.oil_bopd.toLocaleString()} BOPD</span><span>{w.risk} RISK</span>
            <button>INVESTIGATE →</button>
          </div>
        ))}
      </section>

      <section className="workflow">
        <h2>ENGINEERING WORKFLOW</h2>
        <div className="steps">
          {["Investigate","Evidence","Hypotheses","Recommendation","Red Team","Scenario"].map((x,i)=>
            <div className="step" key={x}><span>0{i+1}</span><b>{x}</b></div>
          )}
        </div>
      </section>
    </main>
  );
}
