export const metadata = { title: "NEXUS | Energy Command Center" };
export default function RootLayout({children}) {
  return <html lang="en"><body>{children}</body></html>;
}
