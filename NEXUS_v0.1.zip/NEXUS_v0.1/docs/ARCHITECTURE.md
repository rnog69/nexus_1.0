# NEXUS Architecture

User interface -> API -> engineering services -> analytics -> scenario/economic layer.

Core workflow:
Well -> Investigate -> Evidence -> Hypotheses -> Recommendation -> Red Team -> Scenario.
