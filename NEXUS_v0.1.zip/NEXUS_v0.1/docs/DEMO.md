# Demo Flow

1. Open the Field Command Center.
2. Review field health and production KPIs.
3. Select a well from the watchlist.
4. Inspect anomaly and risk indicators.
5. Review competing hypotheses.
6. Run a scenario.
7. Review the engineering recommendation.
